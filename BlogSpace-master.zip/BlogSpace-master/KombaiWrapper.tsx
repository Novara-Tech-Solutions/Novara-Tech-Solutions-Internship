
import React from 'react';

export default function KombaiWrapper({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
