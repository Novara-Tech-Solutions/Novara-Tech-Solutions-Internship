import * as React from "react";
import type { SVGProps } from "react";
const Component = (props: SVGProps<SVGSVGElement>) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 7.004 13.341" {...props}><path xmlns="http://www.w3.org/2000/svg" fill="currentColor" d="M4.67 7.671h1.667l.667-2.668H4.67V3.668q0-.453.04-.653a.8.8 0 0 1 .347-.494q.32-.187.947-.187h1.001V.094a12 12 0 0 0-.72-.054Q5.668 0 5.095 0q-.921 0-1.62.366A2.54 2.54 0 0 0 2.4 1.414q-.4.735-.4 1.721v1.868h-2v2.668h2v5.67H4.67z" /></svg>;
export default Component;