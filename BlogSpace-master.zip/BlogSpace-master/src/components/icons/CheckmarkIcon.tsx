import * as React from "react";
import type { SVGProps } from "react";
const Component = (props: SVGProps<SVGSVGElement>) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 11.307 8.027" {...props}><path xmlns="http://www.w3.org/2000/svg" fill="currentColor" d="M4.24 6.133 10.373 0l.933.946-7.066 7.08L0 3.773l.933-.933z" /></svg>;
export default Component;