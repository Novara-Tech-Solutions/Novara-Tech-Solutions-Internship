import * as React from "react";
import type { SVGProps } from "react";
const Component = (props: SVGProps<SVGSVGElement>) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 9.34 9.083" {...props}><path xmlns="http://www.w3.org/2000/svg" fill="currentColor" d="M2.23 3.958h7.11v1.167H2.23l3.14 3.129-.83.829L0 4.54 4.54 0l.83.829z" /></svg>;
export default Component;