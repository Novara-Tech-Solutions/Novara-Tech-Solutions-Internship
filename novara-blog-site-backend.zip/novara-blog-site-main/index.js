import express from "express";
import cookieParser from "cookie-parser";
import dotenv from "dotenv";
import authRoutes from "./routes/authRoutes.js";
import postRoutes from "./routes/postRoutes.js";
import commentRoutes from "./routes/commentRoutes.js";
import categoryRoutes from "./routes/categoryRoutes.js";
import { connectDB } from "./database/db.js";
import path from "path";
dotenv.config();

const app = express();
app.use(express.json());
app.use(cookieParser());
app.use("/uploads", express.static(path.join(process.cwd(), "/uploads")));

// Routes


const PORT = process.env.PORT || 5000;

app.get("/", (req, res) => res.json({ message: "API running" }));

app.use("/api/auth", authRoutes);
app.use("/api/posts", postRoutes);
app.use("/api/comments", commentRoutes);
app.use("/api/categories", categoryRoutes);


// app.get("/api/protected", authMiddleware, (req, res) => {
//   res.json({ message: "Protected data", user: req.user });
// });

// app.get("/api/admin-only", authMiddleware, requireRole("admin"), (req, res) => {
//   res.json({ message: "Admin content" });
// });

(async () => {
  await connectDB(process.env.MONGO_URI);
  app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
})();
