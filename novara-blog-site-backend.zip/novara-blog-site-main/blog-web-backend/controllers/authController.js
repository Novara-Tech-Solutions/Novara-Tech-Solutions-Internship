import bcrypt from "bcrypt";
import User from "../models/User.js";
import { signAccessToken, signRefreshToken, verifyRefreshToken } from "../utils/tokens.js";

const SALT_ROUNDS = 12;

// register
export async function register(req, res) {
  try {
    console.log(req.body);
    const { name, email, password, role } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: "Name, email and password are required." });

    const existing = await User.findOne({ email });
    if (existing) return res.status(409).json({ message: "Email already in use." });

    const hashed = await bcrypt.hash(password, SALT_ROUNDS);
    const user = await User.create({ name, email, password: hashed, role: role || "user" });

    // create tokens
    const accessToken = signAccessToken({ id: user._id, role: user.role });
    const refreshToken = signRefreshToken({ id: user._id, role: user.role });

    // Save refreshToken to DB (for invalidation and rotation)
    user.refreshToken = refreshToken;
    await user.save();

    // set httpOnly cookie for refresh token
    res.cookie("jid", refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production", // set true in prod (HTTPS)
      sameSite: "lax",
      maxAge: 1000 * 60 * 60 * 24 * 7 // 7 days (approx)
      // domain: process.env.COOKIE_DOMAIN || undefined
    });

    res.status(201).json({
      message: "User registered",
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
      accessToken
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: "Server error." });
  }
}

// login
export async function login(req, res) {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: "Email and password are required." });

    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ message: "Invalid credentials." });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ message: "Invalid credentials." });

    const accessToken = signAccessToken({ id: user._id, role: user.role });
    const refreshToken = signRefreshToken({ id: user._id, role: user.role });

    user.refreshToken = refreshToken;
    await user.save();

    res.cookie("jid", refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 1000 * 60 * 60 * 24 * 7
    });

    res.json({
      message: "Logged in",
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
      accessToken
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error." });
  }
}

// refresh token endpoint
export async function refreshTokenHandler(req, res) {
  try {
    const token = req.cookies?.jid;
    if (!token) return res.status(401).json({ message: "No refresh token provided." });

    let payload;
    try {
      payload = verifyRefreshToken(token);
    } catch (err) {
      return res.status(401).json({ message: "Invalid refresh token." });
    }

    const user = await User.findById(payload.id);
    if (!user || !user.refreshToken) return res.status(401).json({ message: "Invalid session." });

    // ensure token matches stored token (simple rotation / single refresh token)
    if (user.refreshToken !== token) {
      // possible token theft / reuse
      user.refreshToken = null;
      await user.save();
      return res.status(401).json({ message: "Refresh token mismatch. Please login again." });
    }

    // issue new tokens (rotate)
    const newAccessToken = signAccessToken({ id: user._id, role: user.role });
    const newRefreshToken = signRefreshToken({ id: user._id, role: user.role });

    user.refreshToken = newRefreshToken;
    await user.save();

    res.cookie("jid", newRefreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 1000 * 60 * 60 * 24 * 7
    });

    res.json({ accessToken: newAccessToken });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error." });
  }
}

// logout
export async function logout(req, res) {
  try {
    const token = req.cookies?.jid;
    if (token) {
      // if cookie exists, clear it's stored value in DB for that user
      try {
        const payload = verifyRefreshToken(token);
        const user = await User.findById(payload.id);
        if (user) {
          user.refreshToken = null;
          await user.save();
        }
      } catch (_) {
        // ignore verification errors here
      }
    }

    res.clearCookie("jid", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax"
      // domain: process.env.COOKIE_DOMAIN || undefined
    });

    res.json({ message: "Logged out." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error." });
  }
}
