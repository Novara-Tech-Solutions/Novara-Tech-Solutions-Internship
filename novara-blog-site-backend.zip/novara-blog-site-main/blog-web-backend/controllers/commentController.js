import mongoose from "mongoose";
import Comment from "../models/Comment.js";
import Post from "../models/Post.js";

const isObjectId = (id) => mongoose.Types.ObjectId.isValid(id);

/** Build a nested comment tree from a flat list */
function buildTree(comments) {
  const byId = new Map();
  const roots = [];
  comments.forEach((c) => {
    const node = {
      _id: c._id,
      content: c.content,
      post: c.post,
      author: c.author,
      parentComment: c.parentComment,
      likes: c.likes,
      isApproved: c.isApproved,
      createdAt: c.createdAt,
      updatedAt: c.updatedAt,
      children: [],
    };
    byId.set(String(c._id), node);
  });

  comments.forEach((c) => {
    if (c.parentComment) {
      const parent = byId.get(String(c.parentComment));
      if (parent) parent.children.push(byId.get(String(c._id)));
      else roots.push(byId.get(String(c._id))); // orphan safety
    } else {
      roots.push(byId.get(String(c._id)));
    }
  });

  // recent-first within each level
  const sortDesc = (arr) => {
    arr.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    arr.forEach((n) => sortDesc(n.children));
  };
  sortDesc(roots);

  return roots;
}

/** POST /comments  (auth) */
export async function createComment(req, res) {
  try {
    const { content, postId, parentComment } = req.body;

    if (!content || !postId) {
      return res.status(400).json({ message: "content and postId are required" });
    }
    if (!isObjectId(postId)) return res.status(400).json({ message: "invalid postId" });

    const post = await Post.findById(postId).select("_id author");
    if (!post) return res.status(404).json({ message: "post not found" });

    let parent = null;
    if (parentComment) {
      if (!isObjectId(parentComment)) return res.status(400).json({ message: "invalid parentComment id" });
      parent = await Comment.findById(parentComment).select("_id post");
      if (!parent) return res.status(404).json({ message: "parent comment not found" });
      if (String(parent.post) !== String(postId)) {
        return res.status(400).json({ message: "parent comment does not belong to the same post" });
      }
    }

    const comment = await Comment.create({
      content,
      post: postId,
      author: req.user.id,
      parentComment: parent ? parent._id : null,
      // isApproved defaults to true (per schema); tweak here if you want moderation-first.
    });

    const populated = await Comment.findById(comment._id)
      .populate("author", "name avatar")
      .populate("post", "title slug");

    return res.status(201).json({ message: "comment created", comment: populated });
  } catch (err) {
    console.error("createComment error:", err);
    return res.status(500).json({ message: "server error" });
  }
}

/** GET /comments/post/:postId  (public)
 *  query: page, limit, includePending (bool), tree (bool)
 */
export async function getCommentsForPost(req, res) {
  try {
    const { postId } = req.params;
    if (!isObjectId(postId)) return res.status(400).json({ message: "invalid postId" });

    const post = await Post.findById(postId).select("_id author");
    if (!post) return res.status(404).json({ message: "post not found" });

    const page = Math.max(parseInt(req.query.page || "1", 10), 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit || "20", 10), 1), 100);
    const includePending = String(req.query.includePending || "false") === "true";
    const asTree = String(req.query.tree || "false") === "true";

    // who can see pending? admin or the post author
    const canSeePending =
      includePending &&
      req.user &&
      (req.user.role === "admin" || String(req.user.id) === String(post.author));

    const baseFilter = { post: postId, ...(canSeePending ? {} : { isApproved: true }) };

    if (asTree) {
      // fetch all comments for this post, then build a tree (OK for moderate sizes)
      const all = await Comment.find(baseFilter)
        .sort({ createdAt: -1 })
        .populate("author", "name avatar")
        .lean();

      const tree = buildTree(all);
      return res.json({ total: all.length, comments: tree });
    }

    // flat, paginated (top-level + replies intermixed by date)
    const [items, total] = await Promise.all([
      Comment.find(baseFilter)
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .populate("author", "name avatar")
        .populate("parentComment", "_id")
        .lean(),
      Comment.countDocuments(baseFilter),
    ]);

    return res.json({
      page,
      limit,
      total,
      comments: items,
    });
  } catch (err) {
    console.error("getCommentsForPost error:", err);
    return res.status(500).json({ message: "server error" });
  }
}

/** PATCH /comments/:id  (auth) — author or admin */
export async function updateComment(req, res) {
  try {
    const { id } = req.params;
    const { content } = req.body;
    if (!isObjectId(id)) return res.status(400).json({ message: "invalid id" });
    if (!content) return res.status(400).json({ message: "content is required" });

    const comment = await Comment.findById(id);
    if (!comment) return res.status(404).json({ message: "comment not found" });

    const isOwner = String(comment.author) === String(req.user.id);
    const isAdmin = req.user.role === "admin";
    if (!isOwner && !isAdmin) return res.status(403).json({ message: "forbidden" });

    comment.content = content;
    await comment.save();

    const populated = await Comment.findById(comment._id).populate("author", "name avatar");
    return res.json({ message: "comment updated", comment: populated });
  } catch (err) {
    console.error("updateComment error:", err);
    return res.status(500).json({ message: "server error" });
  }
}

/** helper: collect all descendant comment ids (inclusive) */
async function collectDescendantsInclusive(rootId) {
  const ids = [rootId];
  const stack = [rootId];

  while (stack.length) {
    const current = stack.pop();
    const children = await Comment.find({ parentComment: current }, "_id").lean();
    for (const c of children) {
      ids.push(c._id);
      stack.push(c._id);
    }
  }
  return ids;
}

/** DELETE /comments/:id  (auth) — author, admin, or post author */
export async function deleteComment(req, res) {
  try {
    const { id } = req.params;
    if (!isObjectId(id)) return res.status(400).json({ message: "invalid id" });

    const comment = await Comment.findById(id).select("author post");
    if (!comment) return res.status(404).json({ message: "comment not found" });

    const post = await Post.findById(comment.post).select("author");
    const isOwner = String(comment.author) === String(req.user.id);
    const isAdmin = req.user.role === "admin";
    const isPostAuthor = req.user && String(post.author) === String(req.user.id);

    if (!isOwner && !isAdmin && !isPostAuthor) return res.status(403).json({ message: "forbidden" });

    // cascade delete this comment and all descendants
    const ids = await collectDescendantsInclusive(comment._id);
    await Comment.deleteMany({ _id: { $in: ids } });

    return res.json({ message: "comment and replies deleted", deletedCount: ids.length });
  } catch (err) {
    console.error("deleteComment error:", err);
    return res.status(500).json({ message: "server error" });
  }
}

/** POST /comments/:id/like  (auth) — toggle */
export async function toggleLikeComment(req, res) {
  try {
    const { id } = req.params;
    if (!isObjectId(id)) return res.status(400).json({ message: "invalid id" });

    const comment = await Comment.findById(id);
    if (!comment) return res.status(404).json({ message: "comment not found" });

    const uid = String(req.user.id);
    const idx = comment.likes.findIndex((u) => String(u) === uid);

    let liked;
    if (idx === -1) {
      comment.likes.push(req.user.id);
      liked = true;
    } else {
      comment.likes.splice(idx, 1);
      liked = false;
    }

    await comment.save();
    return res.json({ liked, likesCount: comment.likes.length });
  } catch (err) {
    console.error("toggleLikeComment error:", err);
    return res.status(500).json({ message: "server error" });
  }
}

/** PATCH /comments/:id/approve  (auth) — admin or post author */
export async function approveComment(req, res) {
  try {
    const { id } = req.params;
    const { approved } = req.body; // boolean
    if (!isObjectId(id)) return res.status(400).json({ message: "invalid id" });
    if (typeof approved !== "boolean") return res.status(400).json({ message: "`approved` boolean required" });

    const comment = await Comment.findById(id).select("post isApproved");
    if (!comment) return res.status(404).json({ message: "comment not found" });

    const post = await Post.findById(comment.post).select("author");
    const isAdmin = req.user.role === "admin";
    const isPostAuthor = req.user && String(post.author) === String(req.user.id);
    if (!isAdmin && !isPostAuthor) return res.status(403).json({ message: "forbidden" });

    comment.isApproved = approved;
    await comment.save();

    return res.json({ message: `comment ${approved ? "approved" : "unapproved"}` });
  } catch (err) {
    console.error("approveComment error:", err);
    return res.status(500).json({ message: "server error" });
  }
}
