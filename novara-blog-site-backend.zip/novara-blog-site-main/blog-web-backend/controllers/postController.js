import slugify from "slugify";
import Post from "../models/Post.js";
import PostView from "../models/PostView.js";

export async function createPost(req, res) {
  try {
    const { title, content, excerpt, categories = [], tags = [], status = "draft", isFeatured = false } = req.body;
    if (!title || !content) return res.status(400).json({ message: "title & content required" });

    const slug = slugify(title, { lower: true, strict: true });
    const exists = await Post.findOne({ slug });
    if (exists) return res.status(409).json({ message: "Post with similar title/slug exists" });

    const post = new Post({
      title,
      slug,
      content,
      excerpt,
      author: req.user.id,
      categories,
      tags,
      status,
      isFeatured
    });

    if (req.files?.featuredImage?.[0]) post.featuredImage = `/uploads/${req.files.featuredImage[0].filename}`;
    if (req.files?.video?.[0]) post.videoUrl = `/uploads/${req.files.video[0].filename}`;

    await post.save();
    res.status(201).json({ message: "Post created", post });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Server error" });
  }
}

// GET /posts?search=&status=&category=&tag=&author=&featured=&page=1&limit=10
export async function listPosts(req, res) {
  try {
    const { search = "", status, category, tag, author, featured, page = 1, limit = 10 } = req.query;

    const q = {};
    if (search) q.$or = [
      { title: { $regex: search, $options: "i" } },
      { content: { $regex: search, $options: "i" } },
      { tags: { $regex: search, $options: "i" } }
    ];
    if (status) q.status = status;
    if (category) q.categories = category;
    if (tag) q.tags = tag;
    if (author) q.author = author;
    if (featured !== undefined) q.isFeatured = featured === "true";

    const skip = (Number(page) - 1) * Number(limit);

    const [items, total] = await Promise.all([
      Post.find(q)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(Number(limit))
        .populate("author", "name avatar")
        .populate("categories", "name slug"),
      Post.countDocuments(q)
    ]);

    res.json({ items, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Server error" });
  }
}

export async function getPostBySlug(req, res) {
  try {
    const post = await Post.findOne({ slug: req.params.slug })
      .populate("author", "name avatar")
      .populate("categories", "name slug");
    if (!post) return res.status(404).json({ message: "Post not found" });

    // Track view
    const ip = req.headers["x-forwarded-for"]?.split(",")[0] || req.socket.remoteAddress || req.ip;
    await PostView.create({ post: post._id, user: req.user?.id || null, ipAddress: ip });
    post.views += 1;
    await post.save();

    res.json(post);
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Server error" });
  }
}

export async function updatePost(req, res) {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });
    if (req.user.role !== "admin" && String(post.author) !== req.user.id) return res.status(403).json({ message: "Forbidden" });

    const allowed = ["title", "content", "excerpt", "categories", "tags", "status", "isFeatured"]; 
    for (const k of allowed) if (k in req.body) post[k] = req.body[k];

    if (req.files?.featuredImage?.[0]) post.featuredImage = `/uploads/${req.files.featuredImage[0].filename}`;
    if (req.files?.video?.[0]) post.videoUrl = `/uploads/${req.files.video[0].filename}`;

    if (req.body.title) post.slug = slugify(req.body.title, { lower: true, strict: true });

    await post.save();
    res.json({ message: "Post updated", post });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Server error" });
  }
}

export async function deletePost(req, res) {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });
    if (req.user.role !== "admin" && String(post.author) !== req.user.id) return res.status(403).json({ message: "Forbidden" });

    await post.deleteOne();
    res.json({ message: "Post deleted" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Server error" });
  }
}

export async function toggleLike(req, res) {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const uid = req.user.id;
    const idx = post.likes.findIndex(x => String(x) === uid);
    if (idx >= 0) post.likes.splice(idx, 1); else post.likes.push(uid);

    await post.save();
    res.json({ likes: post.likes.length, liked: idx < 0 });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Server error" });
  }
}