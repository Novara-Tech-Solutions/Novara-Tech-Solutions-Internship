import express from "express";
import { authMiddleware } from "../middleware/auth.js";
import {
  createComment,
  getCommentsForPost,
  updateComment,
  deleteComment,
  toggleLikeComment,
  approveComment,
} from "../controllers/commentController.js";

const router = express.Router();

// public
router.get("/post/:postId", getCommentsForPost); // ?tree=true&includePending=true&page=1&limit=20

// auth-required
router.post("/", authMiddleware, createComment);
router.patch("/:id", authMiddleware, updateComment);
router.delete("/:id", authMiddleware, deleteComment);
router.post("/:id/like", authMiddleware, toggleLikeComment);
router.patch("/:id/approve", authMiddleware, approveComment);

export default router;
