import express from "express";
import {
  createCategory,
  getCategories,
  getCategoryBySlug,
  updateCategory,
  deleteCategory
} from "../controllers/categoryController.js";
import { authMiddleware } from "../middleware/auth.js";
import { requireRole } from "../middleware/roles.js";

const router = express.Router();

// Create a new category (Admin only)
router.post("/", authMiddleware, requireRole("admin"), createCategory);

// Get all categories
router.get("/", getCategories);

// Get category by slug
router.get("/:slug", getCategoryBySlug);

// Update category (Admin only)
router.put("/:id", authMiddleware, requireRole("admin"), updateCategory);

// Delete category (Admin only)
router.delete("/:id", authMiddleware, requireRole("admin"), deleteCategory);

export default router;
