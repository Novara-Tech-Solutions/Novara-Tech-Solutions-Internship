import express from "express";
import {
  createPost,
  listPosts,
  getPostBySlug,
  updatePost,
  deletePost,
  toggleLike
} from "../controllers/postController.js";
import { authMiddleware } from "../middleware/auth.js";
import { requireRole } from "../middleware/roles.js";
import { upload } from "../middleware/upload.js";

const router = express.Router();

// Create a post (auth required)
router.post(
  "/",
  authMiddleware,
  upload.fields([
    { name: "featuredImage", maxCount: 1 },
    { name: "video", maxCount: 1 }
  ]),
  createPost
);

// List all posts
router.get("/", listPosts);

// Get single post by slug
router.get("/:slug", getPostBySlug);

// Update post (auth required)
router.put(
  "/:id",
  authMiddleware,
  upload.fields([
    { name: "featuredImage", maxCount: 1 },
    { name: "video", maxCount: 1 }
  ]),
  updatePost
);

// Delete post (admin only)
router.delete("/:id", authMiddleware, requireRole("admin"), deletePost);

// Toggle like (auth required)
router.patch("/:id/like", authMiddleware, toggleLike);

export default router;
