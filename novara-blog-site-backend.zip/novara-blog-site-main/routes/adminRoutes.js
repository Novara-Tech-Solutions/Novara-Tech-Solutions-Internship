const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { adminOnly } = require('../middleware/auth');

router.get('/users', adminOnly, adminController.getUsers);
router.put('/users/:id/role', adminOnly, adminController.updateUserRole);
router.get('/stats', adminOnly, adminController.getDashboardStats);

module.exports = router;
